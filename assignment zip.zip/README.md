# Findoc Assignment (Flutter)

Two screens using BLoC:
- **Login** with email & password validation
- **Home**: fetch 10 images from https://picsum.photos using static GET API and show list

## Quick Start
1) Extract files into a folder.
2) Open terminal in that folder and run:
   ```bash
   flutter create .
   flutter pub get
   flutter run
   ```
3) Build APK:
   ```bash
   flutter build apk --release
   ```
4) APK: `build/app/outputs/flutter-apk/app-release.apk`

## Notes
- Uses Montserrat via `google_fonts`.
- BLoC pattern with `flutter_bloc` and `equatable`.
